<div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Update Roles</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
<form class="axios-form add-new-record pt-0" action="<?php echo e(url('admin/user/assign-role')); ?>" method="post">
       <?php echo csrf_field(); ?>
       <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
       <div class="modal-body flex-grow-1">
           <div class="form-group custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="ckbCheckAll" />
                <label class="custom-control-label" for="ckbCheckAll">Select all roles.</label>
            </div>
           <div class="row">
           <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php $key += 1;?>
           <div class="col-sm-6 col-12">
           <div class="form-group custom-control custom-checkbox">
      <input type="checkbox" name="role[<?php echo e($role->id); ?>]" vaule="<?php echo e($role->id); ?>"  class="custom-control-input" id="customCheck<?php echo e($key); ?>" <?php if($user->userhasRole($user->id, $role->id)): ?> checked <?php endif; ?>  />
                   <label class="custom-control-label" for="customCheck<?php echo e($key); ?>"><?php echo e($role->name); ?></label>
               </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
       </div> 
       <div class="modal-footer">
       <button type="submit" class="btn btn-primary mr-1 waves-effect waves-float waves-light">Update</button>
       </div>
   </form>
   <script>
     $("#ckbCheckAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
       </script><?php /**PATH /home/kuldeep/public_html/resources/views/ajax/profile/role_update.blade.php ENDPATH**/ ?>