<div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel1">Permissions</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
<form class="axios-form add-new-record pt-0" action="<?php echo e(url('admin/roles/assign-permission')); ?>" method="post">
       <?php echo csrf_field(); ?>
       <input type="hidden" name="id" value="">
       <div class="modal-body flex-grow-1">
           <div class="form-group custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="ckbCheckAll" />
                <label class="custom-control-label" for="ckbCheckAll">Select all permissions.</label>
               </div>
           <div class="row">
      
           <div class="col-sm-6 col-12">
           <div class="form-group custom-control custom-checkbox">
                   <input type="checkbox" name="permission[<?php echo e($user->id); ?>]" vaule="<?php echo e($user->id); ?>" class="custom-control-input" id="customCheck" />
                   <label class="custom-control-label" for="customCheck"><?php echo e($user->name); ?></label>
               </div>
           </div>
           
           </div>
       </div>
       <div class="modal-footer">
       <button type="submit" class="btn btn-primary mr-1 waves-effect waves-float waves-light">Update</button>
       </div>
   </form>
   <script>
       $("#ckbCheckAll").on("change", function () {
           if($('#ckbCheckAll').prop('checked')){
               $(this).parent('form').find('input[type="checkbox"]').each(function(){
                $(this).prop('checked', $(this).prop('checked'));
               });
           }else{
            $(this).parent('form').find('input[type="checkbox"]').each(function(){
                $(this).prop('checked', false);
               });
           }
            

});
       </script><?php /**PATH /home/kuldeep/public_html/resources/views/ajax/user-profile-detail.blade.php ENDPATH**/ ?>