<?php echo e($slot); ?>

<?php /**PATH /home/kuldeep/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>