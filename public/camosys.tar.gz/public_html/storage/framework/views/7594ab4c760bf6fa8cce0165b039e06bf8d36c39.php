<?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4">
              <div class="card">
                  <img class="card-img-top" src="../../../app-assets/images/slider/04.jpg" alt="Card image cap" />
                  <div class="card-body">
                      <h4 class="card-title"><?php echo e($facility->name); ?></h4>
                      <p class="card-text">
                          Some quick example text to build on the card title and make up the bulk of the card's content.
                      </p>
                      <a href="/admin/managefacility/<?php echo e($facility->id); ?>" class="btn btn-outline-primary">View <i data-feather='arrow-right'></i></a>
                  </div>
              </div>
          </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/kuldeep/public_html/resources/views/ajax/facility-card.blade.php ENDPATH**/ ?>