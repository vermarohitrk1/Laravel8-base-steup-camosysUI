<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4 col-6">
                                <div class="card card-profile">
                                    <img src="../../../app-assets/images/banner/banner-12.jpg" class="img-fluid card-img-top" alt="Profile Cover Photo" />
                                    <div class="card-body">
                                        <div class="profile-image-wrapper">
                                            <div class="profile-image">
                                                <div class="avatar">
                                                <?php if(empty($user->profile->profile_img)): ?>
                                                <img src="<?php echo e(asset('/uploads/images/avatar.png')); ?>" alt="Profile Picture" />
                                                <?php else: ?>
                                                <img src="<?php echo e(asset('uploads/images/'.$user->profile->profile_img)); ?>" alt="Profile Picture" />
                                                <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <h3><?php echo e($user->name); ?></h3>
                                        <h6 class="text-muted"><?php echo e($user->address); ?></h6>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($user->userhasRole($user->id, $role->id)): ?><div class="badge badge-light-primary profile-badge"> <?php echo e($role->name); ?></div> <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <hr class="mb-2" />
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                            <a href="<?php echo e(url('admin/userprofile/'.$user->id)); ?>" type="button" class="btn btn-primary waves-effect waves-float waves-light">View</a>
                                            </div>
                                            <div>
                                            <div class="dropdown">
                                                    <button type="button" class="btn btn-sm dropdown-toggle hide-arrow waves-effect waves-float waves-light" data-toggle="dropdown" aria-expanded="false"><div style="font-size:28px;"><i data-feather='more-vertical'></i> </div> </button>
                                                    </button>
                                                    <div class="dropdown-menu" style="">
                                                        <!-- <a class="dropdown-item fetch-display-click" data="id:|_token:<?php echo e(csrf_token()); ?>" url="<?php echo e(url('admin/roles/edit')); ?>" href="javascript:void(0);" holder='.update-holder' modal="#update">
                                                        <i data-feather="edit-2" class="mr-50"></i>
                                                            <span>Edit</span>
                                                        </a> -->
                                                            <a class="waves-effect dropdown-item fetch-display-click" data="id:<?php echo e($user->id); ?>|_token:<?php echo e(csrf_token()); ?>|type:update_role" url="<?php echo e(url('admin/profile/edit')); ?>" href="javascript:void(0);" holder='.update-holder' modal="#large"><i data-feather="edit" class="mr-50"></i>Update Role</a>
                                            
                                              <a class="dropdown-item fetch-display-click"  data="id:<?php echo e($user->id); ?>|_token:<?php echo e(csrf_token()); ?>|type:update_employee_hiring" url="<?php echo e(url('admin/profile/edit')); ?>" href="javascript:void(0);" holder='.update-holder' modal="#large"><i data-feather="edit-3" class="mr-50"></i>Update Employee Information</a>

                                               <a class="dropdown-item fetch-display-click"  data="id:<?php echo e($user->id); ?>|_token:<?php echo e(csrf_token()); ?>|type:update_employee" url="<?php echo e(url('admin/profile/edit')); ?>" href="javascript:void(0);" holder='.update-holder' modal="#large"><i data-feather="edit-3" class="mr-50"></i>Update Account Details</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                               <div class="modal-size-lg d-inline-block">
                                         
                                            <!-- Modal -->
                                            <div class="modal fade text-left" id="large" tabindex="-1" aria-labelledby="myModalLabel17" style="display: none;" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                                    <div class="modal-content">
                                                        
                                                        <div class="update-holder">
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/kuldeep/public_html/resources/views/ajax/users-card.blade.php ENDPATH**/ ?>