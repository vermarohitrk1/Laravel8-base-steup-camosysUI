
<?php $__env->startPush('page-css'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
                        <div class="content-header row">
                            <div class="content-header-left col-md-9 col-12 mb-2">
                                <div class="row breadcrumbs-top">
                                    <div class="col-12">
                                        <h2 class="content-header-title float-left mb-0">Role</h2>
                                        <div class="breadcrumb-wrapper">
                                            <ol class="breadcrumb">
                                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a>
                                                </li>
                                                <li class="breadcrumb-item active">Role
                                                </li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                                <div class="form-group breadcrumb-right">
                                    <button class="dt-button create-new btn btn-primary" tabindex="0" aria-controls="DataTables_Table_0" type="button" data-toggle="modal" data-target="#modals-create"><span>
                                    <i data-feather="plus" class="mr-50"></i> Add New Role</span></button>
                                </div>
                            </div>
                        </div>
                        <div class="content-body">
                            <div class="row justify-content-center">
                                <div class="col-md-12">
                                <section id="basic-datatable">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                            <table class="datatables-basic-- table" id="my-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Slug</th>
                                        
                                            <?php if(Auth::user()->hasRole('superadmin')): ?>
                                            <th>Default</th>
                                            <?php else: ?>
                                            <th>Type</th>
                                            <?php endif; ?>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $key += 1; ?>
                                            <tr>
                                            <th scope="row"><?php echo e($key); ?></th>
                                            <td><?php echo e($role->name); ?></td>
                                            <td><?php echo e($role->slug); ?></td>
                                            <td>
                                                   <?php if(Auth::user()->hasRole('superadmin')): ?>
                                                <form class="switch-button" action="/admin/role/default" action="post">
                                                    <div class="custom-control custom-switch custom-switch-primary">
                                                        <input type="checkbox" class="custom-control-input" name="default_role" data-id="<?php echo e($role->id); ?>" data-token="<?php echo e(csrf_token()); ?>" id="customSwitch<?php echo e($key); ?>" <?php if($role->default_role == 1): ?> checked <?php endif; ?> />
                                                        <label class="custom-control-label" for="customSwitch<?php echo e($key); ?>">
                                                            <span class="switch-icon-left"><i data-feather="check"></i></span>
                                                            <span class="switch-icon-right"><i data-feather="x"></i></span>
                                                        </label>
                                                    </div>
                                                </form>
                                                <?php else: ?>
                                                    <?php if($role->default_role == 1): ?>
                                                       <span>System</span> 
                                                    <?php else: ?>
                                                    <span>Custom</span>
                                                    <?php endif; ?>
                                                   
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                 <?php if(Auth::user()->hasRole('superadmin') || $role->default_role == 0): ?>
                                                <div class="dropdown">
                                                    <button type="button" class="btn btn-sm dropdown-toggle hide-arrow waves-effect waves-float waves-light" data-toggle="dropdown" aria-expanded="false">
                                                    <i data-feather="more-vertical"></i>                                                    </button>
                                                    </button>
                                                    <div class="dropdown-menu" style="">
                                                        <a class="dropdown-item fetch-display-click" data="id:<?php echo e($role->id); ?>|_token:<?php echo e(csrf_token()); ?>" url="<?php echo e(url('admin/roles/edit')); ?>" href="javascript:void(0);" holder='.update-holder' modal="#update">
                                                        <i data-feather="edit-2" class="mr-50"></i>
                                                            <span>Edit</span>
                                                        </a>
                                                        <form class="axios-form" action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item" href="javascript:void(0);">
                                                        <i data-feather="trash" class="mr-50"></i>
                                                            <span>Delete</span>
                                                        </button>
                                                        </form>
                                                    </div>
                                                </div>
                                                <?php else: ?>
                                                      <span>-</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- Modal to add new record -->
                    <div class="modal modal-slide-in fade" id="modals-create">
                        <div class="modal-dialog sidebar-sm">
                            <form class="axios-form dd-new-record modal-content pt-0" action="<?php echo e(route('roles.store')); ?>" method="post">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">×</button>
                                <div class="modal-header mb-1">
                                    <h5 class="modal-title" id="exampleModalLabel">Create New Role</h5>
                                </div>
                                <?php echo csrf_field(); ?>
                                <div class="modal-body flex-grow-1">
                                    <div class="form-group">
                                        <label class="form-label" for="basic-icon-default-fullname">Role Name</label>
                                        <input type="text" class="form-control dt-full-name" id="fullname" name="name" placeholder="Role Name" required>
                                    </div>
                                    <div class="form-group">
                                        <h5>Permissions</h5>
                                        <div class="row">
                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $key += 1;?>
                                                <div class="col-sm-6 col-12">
                                                <div class="form-group custom-control custom-checkbox">
                                                        <input type="checkbox" name="permission[<?php echo e($permission->id); ?>]" vaule="<?php echo e($permission->id); ?>" class="custom-control-input" id="createcustomCheck<?php echo e($key); ?>" />
                                                        <label class="custom-control-label" for="createcustomCheck<?php echo e($key); ?>"><?php echo e($permission->name); ?></label>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary data-submit mr-1 waves-effect waves-float waves-light">Submit</button>
                                    <!-- <button type="reset" class="btn btn-outline-secondary waves-effect" data-dismiss="modal">Cancel</button> -->
                                </div>
                            </form>
                        </div>
                    </div>

                </section>
                 </div>
                 </div>
             </div>
        </div>
    </div>

<!-- modals -->

<div class="modal fade text-left" id="update" tabindex="-1" aria-labelledby="myModalLabel1" style="display: none; padding-right: 17px;" aria-modal="true" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="update-holder"></div>
            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kuldeep/public_html/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>